<footer class="fixed-bottom">
<nav class="navbar navbar-nav  footer1">
<div class="container">
    <div class="col text-center">
  <p class=" footer-copyright a"><a class="footer-block" href="Home.html">&copy;2019 Speed Sound Medium,LLC. All rights reserved. </a></p>
</div>
</div>
</nav>
</footer>
<!-- Javascript -->
        <script src="jquery-3.2.1.min.js"></script>
        <script src="jquery-migrate-3.0.0.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src="jquery.backstretch.min.js"></script>
        <script src="wow.min.js"></script>
        <script src="retina-1.1.0.min.js"></script>
        <script src="scripts.js"></script>
</body>
</html>
